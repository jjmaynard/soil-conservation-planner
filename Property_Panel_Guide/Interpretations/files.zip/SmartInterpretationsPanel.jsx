// ==========================================================================
// SMART INTERPRETATION PRESENTATION COMPONENTS
// React implementation of the interpretation UX framework
// ==========================================================================

import React, { useState, useMemo } from 'react';
import { 
  InterpretationPresentation, 
  userPersonas, 
  disclosureLevels,
  getInterpretationColor,
  getInterpretationIcon,
  educationalContent
} from './interpretationFramework.js';
import { interpretationGroups } from './interpretationGroups.js';

// ==========================================================================
// MAIN SMART INTERPRETATIONS COMPONENT
// ==========================================================================

export function SmartInterpretationsPanel({ 
  interpretations, 
  userPersona = 'scientist',
  context = null,
  onPersonaChange = null 
}) {
  const [presenter] = useState(new InterpretationPresentation(userPersona));
  const [disclosureLevel, setDisclosureLevel] = useState('summary');
  const [showEducation, setShowEducation] = useState(false);
  const [selectedInterpretation, setSelectedInterpretation] = useState(null);

  // Set context if provided
  useMemo(() => {
    if (context) {
      presenter.setContext(context);
    }
  }, [context, presenter]);

  // Process and prioritize interpretations
  const processedData = useMemo(() => {
    const prioritized = presenter.prioritizeInterpretations(interpretations);
    const level = disclosureLevels[disclosureLevel];
    
    const limited = prioritized.slice(0, level.maxItems);
    const explained = limited.map(interp => presenter.explainInterpretation(interp));
    
    // Group by category if needed
    if (level.groupBy === 'category') {
      const grouped = {};
      explained.forEach(exp => {
        const location = findInterpretation(exp.name);
        const groupKey = location?.group || 'other';
        if (!grouped[groupKey]) {
          grouped[groupKey] = [];
        }
        grouped[groupKey].push(exp);
      });
      return { grouped, total: explained.length };
    }
    
    return { linear: explained, total: explained.length };
  }, [interpretations, presenter, disclosureLevel]);

  const persona = userPersonas[userPersona];

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header with persona indicator */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-3">
            <span className="text-2xl">{persona.icon}</span>
            <div>
              <h2 className="text-xl font-bold">Soil Interpretations</h2>
              <p className="text-blue-100 text-sm">{persona.name} View</p>
            </div>
          </div>
          
          {onPersonaChange && (
            <PersonaSelector 
              current={userPersona}
              onChange={onPersonaChange}
            />
          )}
        </div>
        
        <div className="text-sm text-blue-100">
          Showing {processedData.total} most relevant interpretations
          {context && <span> for {context.replace('_', ' ')}</span>}
        </div>
      </div>

      {/* Controls */}
      <div className="p-4 bg-gray-50 border-b">
        <div className="flex flex-wrap items-center gap-4">
          {/* Disclosure Level */}
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">Detail Level:</label>
            <select
              value={disclosureLevel}
              onChange={(e) => setDisclosureLevel(e.target.value)}
              className="text-sm border border-gray-300 rounded px-2 py-1"
            >
              {Object.entries(disclosureLevels).map(([key, level]) => (
                <option key={key} value={key}>{level.name}</option>
              ))}
            </select>
          </div>

          {/* Education Toggle */}
          <button
            onClick={() => setShowEducation(!showEducation)}
            className={`text-sm px-3 py-1 rounded-full border ${
              showEducation 
                ? 'bg-blue-100 text-blue-700 border-blue-300' 
                : 'bg-white text-gray-600 border-gray-300'
            }`}
          >
            📚 Learn Mode
          </button>

          {/* Context indicator */}
          {context && (
            <div className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
              Context: {context.replace('_', ' ')}
            </div>
          )}
        </div>
      </div>

      {/* Educational Content */}
      {showEducation && (
        <EducationalPanel 
          userLevel={persona.characteristics.technicalLevel}
          selectedInterpretation={selectedInterpretation}
        />
      )}

      {/* Interpretations Display */}
      <div className="max-h-[600px] overflow-y-auto">
        {processedData.grouped ? (
          <GroupedInterpretationsView 
            grouped={processedData.grouped}
            persona={persona}
            onSelect={setSelectedInterpretation}
            showEducation={showEducation}
          />
        ) : (
          <LinearInterpretationsView 
            interpretations={processedData.linear}
            persona={persona}
            onSelect={setSelectedInterpretation}
            showEducation={showEducation}
          />
        )}
      </div>

      {/* Quick Summary */}
      <InterpretationSummary 
        interpretations={processedData.linear || Object.values(processedData.grouped || {}).flat()}
        persona={persona}
      />
    </div>
  );
}

// ==========================================================================
// PERSONA SELECTOR COMPONENT
// ==========================================================================

function PersonaSelector({ current, onChange }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 bg-white bg-opacity-20 rounded-lg hover:bg-opacity-30 transition-colors"
      >
        <span className="text-sm">Switch View</span>
        <span className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}>
          ▼
        </span>
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 bg-white rounded-lg shadow-lg border z-50 min-w-48">
          {Object.entries(userPersonas).map(([key, persona]) => (
            <button
              key={key}
              onClick={() => {
                onChange(key);
                setIsOpen(false);
              }}
              className={`w-full text-left px-4 py-3 hover:bg-gray-50 flex items-center space-x-3 ${
                current === key ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
              }`}
            >
              <span className="text-lg">{persona.icon}</span>
              <div>
                <div className="font-medium">{persona.name}</div>
                <div className="text-xs text-gray-500 capitalize">
                  {persona.characteristics.technicalLevel} level
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// GROUPED INTERPRETATIONS VIEW
// ==========================================================================

function GroupedInterpretationsView({ grouped, persona, onSelect, showEducation }) {
  return (
    <div className="divide-y divide-gray-200">
      {Object.entries(grouped).map(([groupKey, interpretations]) => {
        const group = interpretationGroups[groupKey];
        if (!group || interpretations.length === 0) return null;

        return (
          <div key={groupKey} className="p-4">
            <div className="flex items-center space-x-3 mb-4">
              <div 
                className="w-4 h-4 rounded"
                style={{ backgroundColor: group.color }}
              />
              <h3 className="font-semibold text-gray-900 flex items-center space-x-2">
                <span className="text-lg">{group.icon}</span>
                <span>{group.name}</span>
                <span className="text-sm text-gray-500 font-normal">
                  ({interpretations.length})
                </span>
              </h3>
            </div>

            <div className="space-y-2">
              {interpretations.map((interpretation, idx) => (
                <InterpretationCard
                  key={idx}
                  interpretation={interpretation}
                  persona={persona}
                  onSelect={onSelect}
                  showEducation={showEducation}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ==========================================================================
// LINEAR INTERPRETATIONS VIEW
// ==========================================================================

function LinearInterpretationsView({ interpretations, persona, onSelect, showEducation }) {
  return (
    <div className="divide-y divide-gray-200">
      {interpretations.map((interpretation, idx) => (
        <div key={idx} className="p-4">
          <InterpretationCard
            interpretation={interpretation}
            persona={persona}
            onSelect={onSelect}
            showEducation={showEducation}
          />
        </div>
      ))}
    </div>
  );
}

// ==========================================================================
// INTERPRETATION CARD COMPONENT
// ==========================================================================

function InterpretationCard({ interpretation, persona, onSelect, showEducation }) {
  const [expanded, setExpanded] = useState(false);
  const isGoodHigh = interpretation.name.includes('Productivity') || 
                     interpretation.name.includes('Potential') ||
                     interpretation.name.includes('Suitability');
  
  const color = getInterpretationColor(interpretation.value, isGoodHigh);
  const icon = getInterpretationIcon(interpretation);
  
  return (
    <div 
      className={`border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer ${
        expanded ? 'border-blue-300 bg-blue-50' : 'border-gray-200'
      }`}
      onClick={() => {
        setExpanded(!expanded);
        if (showEducation) onSelect(interpretation);
      }}
    >
      {/* Header Row */}
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            <span className="text-lg">{icon}</span>
            <h4 className="font-medium text-gray-900 text-sm leading-tight">
              {interpretation.name.replace(/^(AGR|ENG|FOR|BLM|MIL|DHS|CPS|WMS|URB\/REC|SOH|PFAS|NCCPI|CPI|GRL|SWM) - /, '')}
            </h4>
          </div>
          
          <div className="text-sm text-gray-600 mb-2">
            {interpretation.explanation}
          </div>
          
          <div className="flex items-center space-x-3">
            <span 
              className="text-xs font-medium px-2 py-1 rounded-full text-white"
              style={{ backgroundColor: color }}
            >
              {interpretation.rating}
            </span>
            <span className="text-xs text-gray-500">
              Value: {interpretation.value?.toFixed(3) || 'N/A'}
            </span>
          </div>
        </div>
        
        <div className="ml-4 text-right">
          <div 
            className="text-lg font-bold mb-1"
            style={{ color }}
          >
            {interpretation.interpretation.level.toUpperCase()}
          </div>
          <span className={`transform transition-transform text-gray-400 ${expanded ? 'rotate-180' : ''}`}>
            ▼
          </span>
        </div>
      </div>

      {/* Expanded Content */}
      {expanded && (
        <div className="mt-4 pt-4 border-t border-gray-200 space-y-3">
          {/* Interpretation Message */}
          <div className="bg-gray-50 rounded p-3">
            <p className="text-sm text-gray-700">{interpretation.interpretation.message}</p>
          </div>

          {/* Factors */}
          {interpretation.factors.length > 0 && (
            <div>
              <h5 className="text-xs font-semibold text-gray-700 mb-2">Key Factors:</h5>
              <div className="flex flex-wrap gap-1">
                {interpretation.factors.map((factor, idx) => (
                  <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                    {factor}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Actionable Insights */}
          {interpretation.actionable.length > 0 && (
            <div>
              <h5 className="text-xs font-semibold text-gray-700 mb-2">
                Recommendations for {persona.name}:
              </h5>
              <ul className="text-xs text-gray-600 space-y-1">
                {interpretation.actionable.map((insight, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-green-500 mt-0.5">•</span>
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// EDUCATIONAL PANEL
// ==========================================================================

function EducationalPanel({ userLevel, selectedInterpretation }) {
  const content = educationalContent[userLevel] || educationalContent.beginner;
  
  return (
    <div className="bg-blue-50 border-b p-4">
      <div className="flex items-start space-x-3">
        <div className="text-xl">💡</div>
        <div className="flex-1">
          {selectedInterpretation ? (
            <div>
              <h4 className="font-medium text-blue-900 mb-2">
                About: {selectedInterpretation.name}
              </h4>
              <p className="text-sm text-blue-800">
                {selectedInterpretation.explanation}
              </p>
            </div>
          ) : (
            <div>
              <h4 className="font-medium text-blue-900 mb-2">Understanding Soil Interpretations</h4>
              <div className="text-sm text-blue-800 space-y-2">
                {Object.entries(content.concepts).slice(0, 3).map(([key, concept]) => (
                  <p key={key}><strong>{key.replace(/_/g, ' ')}:</strong> {concept}</p>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// INTERPRETATION SUMMARY
// ==========================================================================

function InterpretationSummary({ interpretations, persona }) {
  const stats = useMemo(() => {
    const summary = {
      total: interpretations.length,
      severe: 0,
      moderate: 0,
      slight: 0,
      topConcerns: [],
      opportunities: []
    };

    interpretations.forEach(interp => {
      const value = interp.value || 0;
      
      if (value >= 0.8) {
        summary.severe++;
        if (interp.interpretation.level === 'severe') {
          summary.topConcerns.push(interp);
        } else if (interp.interpretation.level === 'excellent') {
          summary.opportunities.push(interp);
        }
      } else if (value >= 0.5) {
        summary.moderate++;
      } else {
        summary.slight++;
      }
    });

    summary.topConcerns = summary.topConcerns.slice(0, 3);
    summary.opportunities = summary.opportunities.slice(0, 3);

    return summary;
  }, [interpretations]);

  return (
    <div className="bg-gray-50 p-4">
      <h4 className="font-semibold text-gray-900 mb-3">Quick Summary</h4>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center p-2 bg-red-100 rounded">
          <div className="text-lg font-bold text-red-700">{stats.severe}</div>
          <div className="text-xs text-red-600">High Priority</div>
        </div>
        <div className="text-center p-2 bg-yellow-100 rounded">
          <div className="text-lg font-bold text-yellow-700">{stats.moderate}</div>
          <div className="text-xs text-yellow-600">Moderate</div>
        </div>
        <div className="text-center p-2 bg-green-100 rounded">
          <div className="text-lg font-bold text-green-700">{stats.slight}</div>
          <div className="text-xs text-green-600">Minor/None</div>
        </div>
      </div>

      {/* Top Concerns */}
      {stats.topConcerns.length > 0 && (
        <div className="mb-3">
          <h5 className="text-sm font-medium text-gray-700 mb-1">Key Limitations:</h5>
          <div className="text-xs text-gray-600 space-y-1">
            {stats.topConcerns.map((concern, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <span className="text-red-500">⚠️</span>
                <span>{concern.name.split(' - ')[1] || concern.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Opportunities */}
      {stats.opportunities.length > 0 && (
        <div>
          <h5 className="text-sm font-medium text-gray-700 mb-1">Opportunities:</h5>
          <div className="text-xs text-gray-600 space-y-1">
            {stats.opportunities.map((opportunity, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <span className="text-green-500">✅</span>
                <span>{opportunity.name.split(' - ')[1] || opportunity.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================================================
// CONTEXT-AWARE WRAPPER
// ==========================================================================

export function ContextAwareInterpretations({ 
  interpretations, 
  soilProperties, 
  location,
  defaultPersona = 'scientist' 
}) {
  const [userPersona, setUserPersona] = useState(defaultPersona);
  const [detectedContext, setDetectedContext] = useState(null);

  // Auto-detect context based on soil properties or location
  useMemo(() => {
    if (soilProperties) {
      // Example context detection logic
      if (soilProperties.om > 4 && soilProperties.clay < 30) {
        setDetectedContext('crop_planning');
      } else if (soilProperties.slope > 15) {
        setDetectedContext('forest_management');  
      } else if (location?.urban) {
        setDetectedContext('site_planning');
      }
    }
  }, [soilProperties, location]);

  return (
    <SmartInterpretationsPanel
      interpretations={interpretations}
      userPersona={userPersona}
      context={detectedContext}
      onPersonaChange={setUserPersona}
    />
  );
}

export default SmartInterpretationsPanel;
