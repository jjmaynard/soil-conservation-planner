// ==========================================================================
// SOILVIZ PRO INTEGRATION GUIDE
// Complete integration of the soil interpretations framework
// ==========================================================================

import React, { useState, useEffect } from 'react';
import { SmartInterpretationsPanel, ContextAwareInterpretations } from './SmartInterpretationsPanel.jsx';
import { SoilQualityDashboard, SoilPropertyLegend } from './soilPropertyUsageExamples.js';

// ==========================================================================
// ENHANCED SOILVIZ PRO WITH INTERPRETATIONS
// ==========================================================================

export function SoilVizProEnhanced() {
  const [mapData, setMapData] = useState(null);
  const [soilProperties, setSoilProperties] = useState(null);
  const [interpretations, setInterpretations] = useState([]);
  const [selectedCoordinates, setSelectedCoordinates] = useState(null);
  const [selectedProperty, setSelectedProperty] = useState('clay');
  const [userPersona, setUserPersona] = useState('scientist');
  const [panelView, setPanelView] = useState('properties'); // 'properties' | 'interpretations' | 'both'
  const [loading, setLoading] = useState(false);

  // Fetch soil data when coordinates change
  useEffect(() => {
    if (selectedCoordinates) {
      fetchSoilDataWithInterpretations(selectedCoordinates);
    }
  }, [selectedCoordinates]);

  const fetchSoilDataWithInterpretations = async (coords) => {
    setLoading(true);
    try {
      // Enhanced NRCS SDA query that gets both properties and interpretations
      const query = `
        SELECT 
          -- Map unit info
          mu.mukey, mu.musym, mu.muname,
          
          -- Component info  
          c.compname, c.comppct_r, c.majcompflag,
          
          -- Soil properties from chorizon
          ch.hzdept_r, ch.hzdepb_r,
          ch.claytotal_r, ch.om_r, ch.ph1to1h2o_r, 
          ch.awc_r, ch.ksat_r,
          
          -- Interpretations
          ci.rulename, ci.ruledepth, 
          ci.interphrc, ci.interphr
          
        FROM 
          mapunit mu
          INNER JOIN component c ON c.mukey = mu.mukey
          LEFT JOIN chorizon ch ON ch.cokey = c.cokey
          LEFT JOIN cointerpretation ci ON ci.cokey = c.cokey
          INNER JOIN mupolygon mp ON mp.mukey = mu.mukey
          
        WHERE 
          ST_Intersects(mp.wkb_geometry, 
            ST_GeomFromText('POINT(${coords.lng} ${coords.lat})', 4326))
          AND c.majcompflag = 'Yes'
          
        ORDER BY c.comppct_r DESC, ch.hzdept_r ASC;
      `;

      const response = await fetch('https://sdmdataaccess.nrcs.usda.gov/Tabular/post.rest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          format: 'JSON',
          query: query
        })
      });

      const data = await response.json();
      
      if (data.Table && data.Table[0]) {
        const rows = data.Table[0];
        
        // Process soil properties (take surface horizon values)
        const surfaceHorizon = rows.find(row => row.hzdept_r === 0) || rows[0];
        const properties = {
          clay: surfaceHorizon.claytotal_r,
          om: surfaceHorizon.om_r, 
          ph: surfaceHorizon.ph1to1h2o_r,
          awc: surfaceHorizon.awc_r,
          ksat: surfaceHorizon.ksat_r,
          muname: surfaceHorizon.muname,
          compname: surfaceHorizon.compname,
          comppct: surfaceHorizon.comppct_r
        };

        // Process interpretations (remove duplicates)
        const uniqueInterpretations = [];
        const seen = new Set();
        
        rows.forEach(row => {
          if (row.rulename && !seen.has(row.rulename)) {
            seen.add(row.rulename);
            uniqueInterpretations.push({
              rulename: row.rulename,
              ruledepth: row.ruledepth,
              interphrc: row.interphrc,
              interphr: parseFloat(row.interphr)
            });
          }
        });

        setSoilProperties(properties);
        setInterpretations(uniqueInterpretations);
        
      } else {
        console.warn('No soil data found for location');
        setSoilProperties(null);
        setInterpretations([]);
      }
      
    } catch (error) {
      console.error('Error fetching soil data:', error);
      setSoilProperties(null);
      setInterpretations([]);
    } finally {
      setLoading(false);
    }
  };

  const handleMapClick = (event) => {
    const coords = {
      lat: event.lngLat.lat,
      lng: event.lngLat.lng
    };
    setSelectedCoordinates(coords);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Map Container */}
      <div className="flex-1 relative">
        <div 
          id="map" 
          className="w-full h-full"
          onClick={handleMapClick}
        />
        
        {/* Map Legend */}
        <div className="absolute top-4 left-4 w-64">
          <SoilPropertyLegend 
            property={selectedProperty}
            onPropertyChange={setSelectedProperty}
          />
        </div>

        {/* Loading Indicator */}
        {loading && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg p-4">
            <div className="flex items-center space-x-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-gray-700">Loading soil data...</span>
            </div>
          </div>
        )}

        {/* Location Indicator */}
        {selectedCoordinates && (
          <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3">
            <div className="text-xs text-gray-600">
              Selected Location: {selectedCoordinates.lat.toFixed(4)}, {selectedCoordinates.lng.toFixed(4)}
            </div>
          </div>
        )}
      </div>

      {/* Side Panel */}
      <div className="w-[480px] bg-white flex flex-col shadow-lg">
        {/* Panel Controls */}
        <div className="p-4 border-b bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-gray-900">Soil Analysis Panel</h2>
            <select
              value={userPersona}
              onChange={(e) => setUserPersona(e.target.value)}
              className="text-sm border border-gray-300 rounded px-2 py-1"
            >
              <option value="scientist">🔬 Scientist</option>
              <option value="farmer">🌾 Farmer</option>
              <option value="landManager">🌲 Land Manager</option>
              <option value="engineer">🏗️ Engineer</option>
              <option value="planner">🏙️ Planner</option>
              <option value="consultant">📋 Consultant</option>
            </select>
          </div>

          <div className="flex space-x-1 bg-gray-200 rounded-lg p-1">
            <button
              onClick={() => setPanelView('properties')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                panelView === 'properties'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Properties
            </button>
            <button
              onClick={() => setPanelView('interpretations')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                panelView === 'interpretations'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Interpretations
            </button>
            <button
              onClick={() => setPanelView('both')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                panelView === 'both'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Both
            </button>
          </div>
        </div>

        {/* Panel Content */}
        <div className="flex-1 overflow-hidden">
          {!soilProperties ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-gray-500">
                <div className="text-4xl mb-3">🗺️</div>
                <p className="font-medium">Click on the map to analyze soil</p>
                <p className="text-sm">Select any location to view detailed soil properties and interpretations</p>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col">
              {/* Soil Properties Section */}
              {(panelView === 'properties' || panelView === 'both') && (
                <div className={panelView === 'both' ? 'flex-shrink-0 border-b' : 'flex-1'}>
                  <div className="p-4">
                    <SoilQualityDashboard soilData={soilProperties} />
                  </div>
                </div>
              )}

              {/* Interpretations Section */}
              {(panelView === 'interpretations' || panelView === 'both') && (
                <div className={panelView === 'both' ? 'flex-1 min-h-0' : 'flex-1'}>
                  <ContextAwareInterpretations
                    interpretations={interpretations}
                    soilProperties={soilProperties}
                    location={selectedCoordinates}
                    defaultPersona={userPersona}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// INTERPRETATION EXPORT FUNCTIONS  
// ==========================================================================

export function exportInterpretationReport(interpretations, soilProperties, options = {}) {
  const {
    format = 'pdf', // 'pdf' | 'excel' | 'json'
    userPersona = 'scientist',
    includeMap = true
  } = options;

  const presenter = new InterpretationPresentation(userPersona);
  const prioritized = presenter.prioritizeInterpretations(interpretations);
  const explained = prioritized.map(interp => presenter.explainInterpretation(interp));

  const reportData = {
    metadata: {
      generated: new Date().toISOString(),
      persona: userPersona,
      location: options.coordinates || null,
      totalInterpretations: interpretations.length,
      relevantInterpretations: explained.length
    },
    soilProperties: soilProperties,
    interpretations: explained,
    summary: {
      limitations: explained.filter(e => e.value > 0.6).length,
      opportunities: explained.filter(e => e.interpretation.level === 'excellent').length,
      keyFindings: explained.slice(0, 5).map(e => ({
        name: e.name,
        rating: e.rating,
        significance: e.value > 0.8 ? 'high' : e.value > 0.5 ? 'moderate' : 'low'
      }))
    }
  };

  if (format === 'json') {
    return reportData;
  }

  // For PDF/Excel, you would integrate with libraries like jsPDF or ExcelJS
  console.log('Report data prepared for export:', reportData);
  return reportData;
}

// ==========================================================================
// INTEGRATION WITH MAPPING LIBRARIES
// ==========================================================================

export function setupMapIntegration(map, interpretations) {
  // Add interpretation-based styling to map layers
  
  // Example for MapLibre GL JS
  if (interpretations.length > 0) {
    // Group interpretations by engineering suitability
    const engineeringInterps = interpretations.filter(interp => 
      interp.rulename.startsWith('ENG -')
    );

    if (engineeringInterps.length > 0) {
      // Add a layer showing construction suitability
      map.addLayer({
        id: 'construction-suitability',
        type: 'fill',
        source: 'soil-data',
        paint: {
          'fill-color': [
            'case',
            ['>', ['get', 'eng_limitation'], 0.8], '#dc2626',  // High limitation - red
            ['>', ['get', 'eng_limitation'], 0.5], '#ea580c',  // Moderate - orange
            ['>', ['get', 'eng_limitation'], 0.2], '#ca8a04',  // Slight - yellow
            '#16a34a'  // Suitable - green
          ],
          'fill-opacity': 0.7
        }
      });
    }
  }
}

// ==========================================================================
// EXAMPLE DATA TRANSFORMATION
// ==========================================================================

export function transformSSURGOData(rawData) {
  // Transform your actual SSURGO response to the expected format
  return rawData.map(row => ({
    rulename: row.rulename,
    ruledepth: row.ruledepth,
    interphrc: row.interphrc,
    interphr: parseFloat(row.interphr)
  }));
}

// ==========================================================================
// USAGE EXAMPLES
// ==========================================================================

// Example 1: Basic Integration
/*
import { SoilVizProEnhanced } from './soilVizIntegration.js';

function App() {
  return <SoilVizProEnhanced />;
}
*/

// Example 2: Custom Configuration
/*
import { ContextAwareInterpretations } from './SmartInterpretationsPanel.jsx';

function MyCustomPanel({ interpretations, soilData }) {
  return (
    <div className="w-96">
      <ContextAwareInterpretations
        interpretations={interpretations}
        soilProperties={soilData}
        defaultPersona="farmer"
      />
    </div>
  );
}
*/

// Example 3: Export Integration
/*
function handleExportReport() {
  const report = exportInterpretationReport(
    interpretations,
    soilProperties,
    {
      format: 'json',
      userPersona: 'engineer',
      coordinates: selectedCoordinates
    }
  );
  
  // Send to your backend or download directly
  downloadFile(report, 'soil-analysis-report.json');
}
*/

export default SoilVizProEnhanced;
