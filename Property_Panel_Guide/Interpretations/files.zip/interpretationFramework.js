// ==========================================================================
// SOIL INTERPRETATIONS USER EXPERIENCE FRAMEWORK
// Smart presentation system for SoilViz Pro soil mapping application
// ==========================================================================

// ==========================================================================
// USER PERSONAS & CONTEXT SYSTEM
// ==========================================================================

export const userPersonas = {
  scientist: {
    name: "Soil Scientist/Researcher",
    icon: "🔬",
    characteristics: {
      technicalLevel: "expert",
      interests: ["soilHealth", "geotechnical", "environmentalHazards"],
      preferredMetrics: ["numeric", "statistical", "comparative"],
      detailLevel: "comprehensive"
    },
    defaultGroups: ["soilHealth", "geotechnical", "agricultural", "environmentalHazards"]
  },
  
  farmer: {
    name: "Agricultural Producer",
    icon: "🌾", 
    characteristics: {
      technicalLevel: "practical",
      interests: ["agricultural", "conservation", "waterManagement"],
      preferredMetrics: ["categorical", "practical"],
      detailLevel: "focused"
    },
    defaultGroups: ["agricultural", "conservation", "waterManagement"]
  },
  
  landManager: {
    name: "Land/Forest Manager",
    icon: "🌲",
    characteristics: {
      technicalLevel: "intermediate",
      interests: ["forestry", "rangeland", "conservation"],
      preferredMetrics: ["risk-based", "seasonal"],
      detailLevel: "actionable"
    },
    defaultGroups: ["forestry", "rangeland", "conservation", "environmentalHazards"]
  },
  
  engineer: {
    name: "Civil/Environmental Engineer",
    icon: "🏗️",
    characteristics: {
      technicalLevel: "expert",
      interests: ["engineering", "geotechnical", "waterManagement"],
      preferredMetrics: ["numeric", "specification-based"],
      detailLevel: "technical"
    },
    defaultGroups: ["engineering", "geotechnical", "waterManagement"]
  },
  
  planner: {
    name: "Urban/Regional Planner",
    icon: "🏙️",
    characteristics: {
      technicalLevel: "intermediate", 
      interests: ["engineering", "urbanRecreation", "environmentalHazards"],
      preferredMetrics: ["regulatory", "constraint-based"],
      detailLevel: "summary"
    },
    defaultGroups: ["engineering", "urbanRecreation", "waterManagement", "environmentalHazards"]
  },
  
  consultant: {
    name: "Environmental Consultant",
    icon: "📋",
    characteristics: {
      technicalLevel: "expert",
      interests: ["environmentalHazards", "geotechnical", "waterManagement"],
      preferredMetrics: ["regulatory", "liability-focused"],
      detailLevel: "comprehensive"
    },
    defaultGroups: ["environmentalHazards", "engineering", "waterManagement", "soilHealth"]
  }
};

// ==========================================================================
// INTERPRETATION EXPLANATION SYSTEM
// ==========================================================================

export const interpretationExplanations = {
  // Agricultural Interpretations
  "AGR - Industrial Hemp for Fiber and Seed Production": {
    purpose: "Evaluates soil suitability for industrial hemp cultivation",
    factors: ["drainage", "pH", "organic matter", "texture"],
    goodValues: { min: 0.7, max: 1.0 },
    explanation: {
      scientist: "Assessment based on optimal soil conditions for Cannabis sativa cultivation including pH 6.0-7.5, adequate drainage, and organic matter content.",
      farmer: "Shows how well your soil supports hemp growing. Higher values mean better conditions for good yields.",
      simple: "Soil quality for growing hemp plants"
    },
    limitations: {
      high: "Soil conditions are well-suited for hemp production",
      moderate: "Some soil conditions may limit hemp yields",
      low: "Soil conditions are not suitable for hemp production",
      zero: "Soil is not suited for hemp cultivation"
    }
  },

  "AGR - Nitrate Leaching Potential, Irrigated (WA)": {
    purpose: "Assesses risk of nitrate movement to groundwater under irrigation",
    factors: ["soil texture", "drainage", "water table depth", "permeability"],
    goodValues: { min: 0.0, max: 0.3 },
    explanation: {
      scientist: "Quantifies potential for NO3- transport through soil profile based on hydraulic conductivity, texture, and depth to water table.",
      farmer: "Risk of fertilizer nitrogen leaching into groundwater. Lower values mean less environmental risk.",
      simple: "Risk of fertilizer washing into groundwater"
    },
    limitations: {
      high: "High risk of nitrate contamination - careful fertilizer management needed",
      moderate: "Moderate leaching risk - monitor fertilizer application timing",
      low: "Low leaching risk - standard fertilizer practices appropriate",
      zero: "Minimal leaching risk"
    }
  },

  "ENG - Dwellings W/O Basements": {
    purpose: "Evaluates soil limitations for house construction without basements",
    factors: ["shrink-swell", "bearing capacity", "drainage", "slope"],
    goodValues: { min: 0.0, max: 0.3 },
    explanation: {
      engineer: "Assessment of foundation stability considering bearing capacity, differential settlement, and moisture-related volume change.",
      planner: "Shows construction challenges for houses. Higher values mean more expensive foundation requirements.",
      simple: "How difficult it is to build a house on this soil"
    },
    limitations: {
      high: "Very limited - significant foundation engineering required",
      moderate: "Somewhat limited - special foundation design may be needed",
      low: "Minor limitations - standard construction practices apply",
      zero: "No significant limitations for construction"
    }
  },

  "FOR - Rutting Hazard by Season": {
    purpose: "Evaluates soil susceptibility to equipment rutting during forest operations",
    factors: ["soil strength", "moisture content", "texture", "season"],
    goodValues: { min: 0.0, max: 0.4 },
    explanation: {
      landManager: "Risk assessment for soil damage from heavy forestry equipment, varies by season and moisture conditions.",
      scientist: "Quantifies soil bearing capacity and rut formation potential under standard forestry equipment loading.",
      simple: "Risk of soil damage from heavy equipment in forests"
    },
    limitations: {
      high: "Severe rutting risk - restrict operations during wet periods",
      moderate: "Moderate rutting risk - seasonal restrictions may apply", 
      low: "Low rutting risk - standard equipment operations acceptable",
      zero: "Minimal rutting risk"
    }
  },

  "PFAS - Chemical Attenuation in Soils": {
    purpose: "Assesses soil's ability to reduce PFAS contamination movement",
    factors: ["organic matter", "clay content", "pH", "amorphous materials"],
    goodValues: { min: 0.6, max: 1.0 },
    explanation: {
      consultant: "Evaluates soil capacity for PFAS sorption and degradation based on key soil properties affecting contaminant fate and transport.",
      scientist: "Quantifies potential for per- and polyfluoroalkyl substance attenuation through soil matrix interactions.",
      simple: "How well soil can filter out PFAS chemicals"
    },
    limitations: {
      high: "High attenuation capacity - soil provides good PFAS filtration",
      moderate: "Moderate attenuation - some PFAS reduction occurs",
      low: "Low attenuation capacity - limited PFAS removal",
      zero: "Minimal attenuation - PFAS likely to migrate freely"
    }
  }
};

// ==========================================================================
// PRESENTATION FRAMEWORK
// ==========================================================================

export class InterpretationPresentation {
  constructor(userPersona = 'scientist') {
    this.persona = userPersonas[userPersona] || userPersonas.scientist;
    this.contextualFilters = new Set();
    this.currentContext = null;
  }

  // Set user context for relevant interpretations
  setContext(context) {
    const contextMappings = {
      'site_planning': {
        groups: ['engineering', 'urbanRecreation', 'environmentalHazards'],
        priorities: ['construction', 'utilities', 'hazards']
      },
      'crop_planning': {
        groups: ['agricultural', 'conservation', 'waterManagement'], 
        priorities: ['productivity', 'sustainability', 'water_use']
      },
      'forest_management': {
        groups: ['forestry', 'conservation', 'environmentalHazards'],
        priorities: ['operations', 'sustainability', 'fire_risk']
      },
      'environmental_assessment': {
        groups: ['environmentalHazards', 'soilHealth', 'waterManagement'],
        priorities: ['contamination', 'remediation', 'protection']
      }
    };
    
    this.currentContext = contextMappings[context] || null;
  }

  // Filter and prioritize interpretations based on user and context
  prioritizeInterpretations(interpretations) {
    let relevant = interpretations;
    
    // Filter by user interests
    if (this.persona.defaultGroups) {
      relevant = relevant.filter(interp => {
        const location = findInterpretation(interp.rulename);
        return !location || this.persona.defaultGroups.includes(location.group);
      });
    }

    // Apply contextual filtering
    if (this.currentContext) {
      relevant = relevant.filter(interp => {
        const location = findInterpretation(interp.rulename);
        return !location || this.currentContext.groups.includes(location.group);
      });
    }

    // Sort by relevance and value
    return relevant.sort((a, b) => {
      // Prioritize interpretations with meaningful values
      const aValue = parseFloat(a.interphr) || 0;
      const bValue = parseFloat(b.interphr) || 0;
      
      // High values (>0.8) or very low values (<0.2) are more noteworthy
      const aRelevance = (aValue > 0.8 || aValue < 0.2) ? 1 : 0;
      const bRelevance = (bValue > 0.8 || bValue < 0.2) ? 1 : 0;
      
      if (aRelevance !== bRelevance) {
        return bRelevance - aRelevance;
      }
      
      return Math.abs(0.5 - bValue) - Math.abs(0.5 - aValue);
    });
  }

  // Generate user-appropriate explanation
  explainInterpretation(interpretation) {
    const value = parseFloat(interpretation.interphr) || 0;
    const explanation = interpretationExplanations[interpretation.rulename];
    
    if (!explanation) {
      return this.generateGenericExplanation(interpretation);
    }

    const userExplanation = explanation.explanation[this.persona.characteristics.technicalLevel] ||
                           explanation.explanation.simple;

    return {
      name: interpretation.rulename,
      rating: interpretation.interphrc,
      value: value,
      explanation: userExplanation,
      interpretation: this.interpretValue(value, explanation),
      factors: explanation.factors || [],
      actionable: this.getActionableInsights(interpretation, explanation)
    };
  }

  // Interpret numeric value based on interpretation type
  interpretValue(value, explanation) {
    const isGoodHigh = explanation.goodValues && explanation.goodValues.min > 0.5;
    
    if (value === null || value === undefined) {
      return { level: 'unknown', message: 'Not rated for this location' };
    }

    if (explanation.goodValues) {
      const { min, max } = explanation.goodValues;
      if (value >= min && value <= max) {
        return { level: 'good', message: explanation.limitations?.low || 'Suitable conditions' };
      }
    }

    // Standard interpretation for most limitation-based interpretations
    if (value >= 0.8) {
      return { 
        level: isGoodHigh ? 'excellent' : 'severe', 
        message: explanation.limitations?.high || (isGoodHigh ? 'Excellent conditions' : 'Severe limitations')
      };
    } else if (value >= 0.5) {
      return { 
        level: 'moderate', 
        message: explanation.limitations?.moderate || 'Moderate limitations'
      };
    } else if (value > 0.1) {
      return { 
        level: isGoodHigh ? 'poor' : 'slight', 
        message: explanation.limitations?.low || (isGoodHigh ? 'Poor conditions' : 'Slight limitations')
      };
    } else {
      return { 
        level: isGoodHigh ? 'very_poor' : 'minimal', 
        message: explanation.limitations?.zero || (isGoodHigh ? 'Very poor conditions' : 'Minimal limitations')
      };
    }
  }

  // Generate actionable insights based on user persona
  getActionableInsights(interpretation, explanation) {
    const value = parseFloat(interpretation.interphr) || 0;
    const insights = [];

    // Persona-specific insights
    switch (this.persona.name) {
      case "Agricultural Producer":
        if (interpretation.rulename.includes('Nitrate Leaching') && value > 0.6) {
          insights.push("Consider split nitrogen applications and cover crops");
          insights.push("Monitor groundwater quality");
        }
        if (interpretation.rulename.includes('Industrial Hemp') && value < 0.3) {
          insights.push("Consider soil amendments to improve conditions");
          insights.push("May need alternative crops for this area");
        }
        break;

      case "Civil/Environmental Engineer":
        if (interpretation.rulename.includes('Dwellings') && value > 0.7) {
          insights.push("Detailed geotechnical investigation recommended");
          insights.push("Consider engineered foundation systems");
        }
        if (interpretation.rulename.includes('Excavations') && value > 0.6) {
          insights.push("Slope stability analysis required");
          insights.push("Dewatering systems may be necessary");
        }
        break;

      case "Land/Forest Manager":
        if (interpretation.rulename.includes('Rutting') && value > 0.8) {
          insights.push("Restrict operations during wet seasons");
          insights.push("Consider low ground pressure equipment");
        }
        if (interpretation.rulename.includes('Fire Damage') && value > 0.5) {
          insights.push("Implement fire prevention measures");
          insights.push("Consider fuel reduction treatments");
        }
        break;
    }

    return insights;
  }

  // Generate explanation for interpretations not in the database
  generateGenericExplanation(interpretation) {
    const value = parseFloat(interpretation.interphr) || 0;
    
    return {
      name: interpretation.rulename,
      rating: interpretation.interphrc,
      value: value,
      explanation: `Assessment of soil conditions for ${interpretation.rulename.toLowerCase()}`,
      interpretation: this.getGenericInterpretation(value),
      factors: [],
      actionable: []
    };
  }

  getGenericInterpretation(value) {
    if (value === null || value === undefined) {
      return { level: 'unknown', message: 'Not rated' };
    }
    if (value >= 0.8) return { level: 'high', message: 'High value/severe limitation' };
    if (value >= 0.5) return { level: 'moderate', message: 'Moderate value/limitation' };
    if (value > 0.1) return { level: 'low', message: 'Low value/slight limitation' };
    return { level: 'minimal', message: 'Minimal value/limitation' };
  }
}

// ==========================================================================
// PROGRESSIVE DISCLOSURE SYSTEM
// ==========================================================================

export const disclosureLevels = {
  overview: {
    name: "Quick Overview",
    description: "Top 5 most relevant interpretations",
    maxItems: 5,
    showDetails: false,
    groupBy: "relevance"
  },
  
  summary: {
    name: "Summary View", 
    description: "Key interpretations by category",
    maxItems: 20,
    showDetails: true,
    groupBy: "category"
  },
  
  detailed: {
    name: "Detailed Analysis",
    description: "Comprehensive interpretation list",
    maxItems: 100,
    showDetails: true,
    groupBy: "category",
    showTechnical: true
  },
  
  complete: {
    name: "Complete Database",
    description: "All available interpretations",
    maxItems: 500,
    showDetails: true,
    groupBy: "category",
    showTechnical: true,
    showLowRelevance: true
  }
};

// ==========================================================================
// VISUAL PRESENTATION HELPERS
// ==========================================================================

export function getInterpretationColor(value, isGoodHigh = false) {
  if (value === null || value === undefined) return '#9ca3af'; // gray
  
  if (isGoodHigh) {
    // For interpretations where high values are good (e.g., productivity)
    if (value >= 0.8) return '#16a34a'; // green
    if (value >= 0.5) return '#ca8a04'; // yellow
    if (value > 0.1) return '#dc2626'; // red
    return '#7f1d1d'; // dark red
  } else {
    // For interpretations where high values indicate limitations
    if (value >= 0.8) return '#dc2626'; // red (severe limitation)
    if (value >= 0.5) return '#ea580c'; // orange (moderate limitation)
    if (value > 0.1) return '#ca8a04'; // yellow (slight limitation)
    return '#16a34a'; // green (no limitation)
  }
}

export function getInterpretationIcon(interpretation) {
  const name = interpretation.rulename.toLowerCase();
  
  if (name.includes('hemp') || name.includes('crop')) return '🌾';
  if (name.includes('water') || name.includes('irrigation')) return '💧';
  if (name.includes('building') || name.includes('dwelling')) return '🏠';
  if (name.includes('road') || name.includes('construction')) return '🚧';
  if (name.includes('forest') || name.includes('tree')) return '🌲';
  if (name.includes('hazard') || name.includes('risk')) return '⚠️';
  if (name.includes('military') || name.includes('vehicle')) return '🎖️';
  if (name.includes('pfas') || name.includes('contamination')) return '☣️';
  if (name.includes('organic') || name.includes('carbon')) return '🧪';
  
  return '📋'; // default
}

// ==========================================================================
// EDUCATIONAL CONTENT SYSTEM
// ==========================================================================

export const educationalContent = {
  beginner: {
    concepts: {
      "soil_limitations": "Soil limitations describe conditions that restrict how soil can be used for specific purposes.",
      "interpretation_values": "Values typically range from 0-1, where meaning depends on the specific interpretation.",
      "soil_properties": "Soil properties like texture, drainage, and chemistry affect how suitable soil is for different uses."
    },
    tutorials: [
      {
        title: "Understanding Soil Interpretations",
        steps: [
          "Interpretations evaluate soil for specific uses",
          "Values help compare different soil areas", 
          "Red colors usually indicate limitations",
          "Green colors typically show good conditions"
        ]
      }
    ]
  },
  
  intermediate: {
    concepts: {
      "limitation_classes": "Very Limited (>0.8), Somewhat Limited (0.4-0.8), Not Limited (<0.4)",
      "seasonal_variations": "Many interpretations vary by season due to moisture and temperature changes",
      "depth_considerations": "Surface (0cm) vs subsurface (1cm) evaluations address different soil layers"
    }
  },
  
  expert: {
    concepts: {
      "fuzzy_logic": "Many interpretations use fuzzy logic curves rather than simple threshold values",
      "weighted_averages": "Some interpretations calculate weighted averages over multiple soil horizons",
      "regional_calibration": "Interpretations may be calibrated for specific Major Land Resource Areas (MLRAs)"
    }
  }
};

export default {
  userPersonas,
  InterpretationPresentation,
  interpretationExplanations,
  disclosureLevels,
  getInterpretationColor,
  getInterpretationIcon,
  educationalContent
};
